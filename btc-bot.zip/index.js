const express = require('express');
const fetch = require('node-fetch');
const { RSI, MACD } = require('technicalindicators');

const app = express();
app.use(express.static('views'));

let prices = [];
let lastSignal = "Esperando...";

async function fetchBTC() {
  try {
    const res = await fetch('https://api.coingecko.com/api/v3/coins/bitcoin/market_chart?vs_currency=usd&days=1');
    const data = await res.json();
    prices = data.prices.map(p => p[1]);

    const rsi = RSI.calculate({ period: 14, values: prices.slice(-100) });
    const macd = MACD.calculate({
      values: prices.slice(-100),
      fastPeriod: 12,
      slowPeriod: 26,
      signalPeriod: 9,
      SimpleMAOscillator: false,
      SimpleMASignal: false
    });

    const lastRSI = rsi[rsi.length - 1];
    const lastMACD = macd[macd.length - 1];

    if (lastRSI < 30 && lastMACD.MACD > lastMACD.signal) {
      lastSignal = "Señal de COMPRA fuerte";
    } else if (lastRSI > 70 && lastMACD.MACD < lastMACD.signal) {
      lastSignal = "Señal de VENTA fuerte";
    } else {
      lastSignal = "Sin señal clara";
    }

  } catch (e) {
    console.error("Error al obtener precios:", e);
  }
}

setInterval(fetchBTC, 60000);
fetchBTC();

app.get('/signal', (req, res) => {
  res.send({ signal: lastSignal });
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Bot corriendo en puerto ${port}`));
